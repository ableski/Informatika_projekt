﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gyerunkmar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addButton_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(taskTextBox.Text))
            {
                string task = $"{taskTextBox.Text} - Határidő: {dueDatePicker.Value.ToShortDateString()}";
                taskListBox.Items.Add(task);
                taskTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Kérlek add meg a feladatot.");
            }
        }

        private void completeButton_Click_1(object sender, EventArgs e)
        {
            if (taskListBox.SelectedItem != null)
            {
                string task = taskListBox.SelectedItem.ToString();
                taskListBox.Items.Remove(task);
                taskListBox.Items.Add($"[Kész] {task}");
            }
            else
            {
                MessageBox.Show("Kérlek válassz ki egy feladatot hogy késznek jelöld!");
            }
        }

        private void deleteButton_Click_1(object sender, EventArgs e)
        {
            if (taskListBox.SelectedItem != null)
            {
                taskListBox.Items.Remove(taskListBox.SelectedItem);
            }
            else
            {
                MessageBox.Show("Válassz ki egy feladatot a törléshez.");
            }
        }
    }
}